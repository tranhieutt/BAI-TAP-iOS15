//
//  ResizeImage.h
//  Core_image_V4
//
//  Created by ios15 on 8/12/13.
//  Copyright (c) 2013 TechMaster. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResizeImage : UIImage



-(UIImage *)resizeImage:(UIImage *)image width:(float) ratio;


@end
