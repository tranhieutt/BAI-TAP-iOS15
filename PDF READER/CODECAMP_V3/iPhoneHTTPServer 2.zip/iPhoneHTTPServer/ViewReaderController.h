//
//  ViewReaderController.h
//  iPhoneHTTPServer
//
//  Created by HieuCoder on 8/30/13.
//
//

#import <UIKit/UIKit.h>
#import "ReaderViewController.h"
@interface ViewReaderController : UIViewController 

- (void) initReaderfile: (NSString *)filePath;
@end
