//
//  ReaderBookDelegate.h
//  iPhoneHTTPServer
//
//  Created by HieuCoder on 8/28/13.
//
//

#import <Foundation/Foundation.h>

@interface ReaderBookDelegate : NSObject <UIApplicationDelegate>


@end
