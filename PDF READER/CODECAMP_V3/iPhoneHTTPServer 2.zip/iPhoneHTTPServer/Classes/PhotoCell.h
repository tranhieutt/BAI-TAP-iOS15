//
//  PhotoCell.h
//  iPhoneHTTPServer
//
//  Created by HieuCoder on 8/28/13.
//
//

#import <UIKit/UIKit.h>

@interface PhotoCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imagePhotoCell;
@property (weak, nonatomic) IBOutlet UILabel *titleCell;

@end
