//
//  SpringboardLayoutAtributes.h
//  iPhoneHTTPServer
//
//  Created by Mac on 8/29/13.
//
//

#import <UIKit/UIKit.h>

@interface SpringboardLayoutAtributes : UICollectionViewLayoutAttributes

@property (nonatomic,getter = isDeleteButtonHidden) BOOL deleteButtonHidden;


@end
