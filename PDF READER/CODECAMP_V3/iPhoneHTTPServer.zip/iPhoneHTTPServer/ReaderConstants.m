//
//  ReaderConstants.m
//  iPhoneHTTPServer
//
//  Created by HieuCoder on 8/28/13.
//
//


#import "ReaderConstants.h"

NSString *const kReaderCopyrightNotice = @"Reader v2.x • Copyright © 2011-2013 Julius Oklamcak. All rights reserved.";
