//
//  ViewController.h
//  iPhoneHTTPServer
//
//  Created by Mac on 8/29/13.
//
//

#import <UIKit/UIKit.h>
#import "SpringBoardLayout.h"
#import "ReaderViewController.h"
#import "ViewReaderController.h"
#import "Web_ViewController.h"

@interface ViewController : UICollectionViewController <SpringboardLayoutDelegate,UIGestureRecognizerDelegate, ReaderContentViewDelegate>
@property (strong,nonatomic) NSMutableArray *itemsInApps;
@property (strong,nonatomic) NSURL *currentURL;
@property   (strong,nonatomic) UIActivityViewController *shareController;
@property   (strong,nonatomic) NSURL *url;


@end
