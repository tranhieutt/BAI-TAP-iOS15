//
//  ReaderBookDelegate.m
//  iPhoneHTTPServer
//
//  Created by HieuCoder on 8/28/13.
//
//

#import "ReaderBookDelegate.h"


@implementation ReaderBookDelegate

@end
