//
//  ReaderContenTile.h
//  iPhoneHTTPServer
//
//  Created by HieuCoder on 8/28/13.
//
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface ReaderContenTile : CATiledLayer

@end
