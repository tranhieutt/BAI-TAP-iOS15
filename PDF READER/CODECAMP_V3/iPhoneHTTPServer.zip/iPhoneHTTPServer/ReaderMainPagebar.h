//
//  ReaderMainPagebar.h
//  iPhoneHTTPServer
//
//  Created by HieuCoder on 8/28/13.
//
//

#import <UIKit/UIKit.h>

@interface ReaderMainPagebar : UIView

@end
