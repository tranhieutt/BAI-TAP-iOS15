//
//  Icon.h
//  iPhoneHTTPServer
//
//  Created by Mac on 8/29/13.
//
//

#import <UIKit/UIKit.h>

@interface Icon : UICollectionViewCell
@property (nonatomic,strong) UILabel *label;
@property   (nonatomic,strong) UIImageView *imageView;
@property  (nonatomic,strong) UIButton *deleteButton;


@end
