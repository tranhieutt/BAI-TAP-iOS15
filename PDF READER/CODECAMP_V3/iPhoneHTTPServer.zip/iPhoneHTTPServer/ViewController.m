//
//  ViewController.m
//  iPhoneHTTPServer
//
//  Created by Mac on 8/29/13.
//
//

#import "ViewController.h"
#import "Icon.h"
#import "SpringBoardLayout.h"
#import "FileManager.h"
@interface ViewController ()
{
    BOOL isDeletionModelActive;
    
}

@end

@implementation ViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"NEW";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.collectionView registerClass:[Icon class] forCellWithReuseIdentifier:@"ICON"];
    
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(activateDeletionMode:)];
    longPress.delegate = self;
    [self.collectionView addGestureRecognizer:longPress];
    //
    UITapGestureRecognizer  *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(endDeletionMode:)];
    tap.delegate  = self;
    [self.collectionView addGestureRecognizer:tap];
    
    // Cham 2 lan to share
    UITapGestureRecognizer *doubletap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(share:)];
    doubletap.numberOfTapsRequired = 2;
    doubletap.numberOfTouchesRequired = 2;
    //doubletap.delegate = self;
    [self.collectionView addGestureRecognizer:doubletap];
    //
    
    FileManager *fm = [[FileManager alloc]init];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString * downloadDirPath = [paths objectAtIndex:0];
    
    _url = [[NSURL alloc] initFileURLWithPath:downloadDirPath];
    NSLog(@"%@",_url);
    _itemsInApps = [fm contentOfAppBundle:_url];
    
    
    
    NSArray *directoryContents = [[NSArray alloc] init];
    NSError *error;
    directoryContents =  [[NSFileManager defaultManager]
                          contentsOfDirectoryAtPath:downloadDirPath error:&error];
    
    
    
    
    // ReaderDocument *document = [ReaderDocument withDocumentFilePath:directoryContents password:nil];
    
    //NSURL *url1 =  [[NSURL alloc] initWithString:[directoryContents objectAtIndex:4]];
    //NSLog(@" tset dpwmn %@",_itemsInApps);
}
- (void)share
{
    NSLog(@"share");
    
    
    //        self.shareController = [[UIActivityViewController alloc] initWithActivityItems:sender applicationActivities:nil];
    //        [self presentViewController:self.shareController animated:YES completion:nil];
    
    
}
//- (NSInteger    )numberOfSectionsInCollectionView:(UICollectionView *)collectionView
//{
//    return 8;
//}
- (NSInteger) collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return _itemsInApps.count;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    Icon *icon = [collectionView dequeueReusableCellWithReuseIdentifier:@"ICON" forIndexPath:indexPath  ];
    
    
    NSString *filePath = [_itemsInApps objectAtIndex:indexPath.row];
    NSString *fileName = [filePath lastPathComponent];
    NSArray *array = [fileName componentsSeparatedByString:@"."];
    NSString *format = array[array.count - 1];
    format = [format lowercaseString];
    if([format isEqualToString:@"png"] || [format isEqualToString:@"jpg"] || [format isEqualToString:@"jpeg"]){
        icon.imageView.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[_itemsInApps objectAtIndex:indexPath.row]]];
    }else if ([format isEqualToString:@"pdf"]) {
        icon.imageView.image = [UIImage imageNamed:@"pdf_file.png"];
    }
    else if ([format isEqualToString:@"html"])
    {
        icon.imageView.image = [UIImage imageNamed:@"HTML.png"];
    }
    
    
    [icon.deleteButton addTarget:self action:@selector(delete:) forControlEvents:UIControlEventTouchUpInside];
    return  icon;
}
- (BOOL) isDeletionModeActiveForCollectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout
{
    return isDeletionModelActive;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - delete for button
- (void)delete:(UIButton *  )sender
{
    NSIndexPath *indexPath = [self.collectionView indexPathForCell:(Icon *) sender.superview.superview];
    [_itemsInApps removeObjectAtIndex:indexPath.row];
    [self.collectionView deleteItemsAtIndexPaths:[NSArray arrayWithObject:indexPath]];
}
#pragma mark- gesture- recognitiong action method// Xac nhan tinh nang gestureRecognizer
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    CGPoint touchPoint = [touch locationInView:self.collectionView];
    NSIndexPath *indexPath = [self.collectionView indexPathForItemAtPoint:touchPoint];
    if (indexPath && [gestureRecognizer isKindOfClass:[UITapGestureRecognizer class]]) {
        return NO;
    }
    return YES;
}
- (void)activateDeletionMode : (UILongPressGestureRecognizer*)longPress
{
    if (longPress.state == UIGestureRecognizerStateBegan)
    {
        NSIndexPath *indexPath = [self.collectionView indexPathForItemAtPoint:[longPress locationInView:self.collectionView]];
        if (indexPath)
        {
            isDeletionModelActive                     = YES;
            SpringBoardLayout *layout                 = (SpringBoardLayout *) self.collectionView.collectionViewLayout;
            [layout invalidateLayout];
        }
        
        
    }
}
- (void)endDeletionMode : (UITapGestureRecognizer *) tap
{
    if (isDeletionModelActive)
    {
        NSIndexPath *indexPath                        = [self.collectionView indexPathForItemAtPoint:[tap locationInView:self.collectionView]] ;
        if (!indexPath)
        {
            isDeletionModelActive = NO;
            SpringBoardLayout *layout                 = (SpringBoardLayout *)self.collectionView.collectionViewLayout;
            [layout invalidateLayout];
        }
    }
}
#pragma mark - new ViewController

-(void) collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath // Chu y: ham didDeSelect:The collection view calls this method when the user successfully deselects an item in the collection view. It does not call this method when you programmatically deselect items
{
    
    
    NSUInteger *row                                  = indexPath.row;
    NSString *filePath                               = [_itemsInApps objectAtIndex:indexPath.row];
    NSString *fileName                               = [filePath lastPathComponent];
    NSArray *array                                   = [fileName componentsSeparatedByString:@"."];
    NSString *format                                 = array[array.count - 1];
    format                                           = [format lowercaseString];
    
    if([format isEqualToString:@"png"] || [format isEqualToString:@"jpg"] || [format isEqualToString:@"jpeg"])
    {
        
        UIViewController *vc                         = [[UIViewController alloc]init];
        vc.view.frame                                = [UIScreen mainScreen].bounds;
        
        NSData  *data                                = [NSData dataWithContentsOfURL:filePath];
        UIImage *image                               = [UIImage imageWithData:data];
        UIImageView *imageView                       = [[UIImageView alloc]initWithImage:image];
        imageView.frame                              = CGRectMake(0, 0, vc.view.frame.size.width, vc.view.frame.size.height);
        [vc.view addSubview:imageView];
        
        UIToolbar *toolbar                           = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, vc.view.frame.size.width, 48)];
        [toolbar setBackgroundImage:[UIImage imageNamed:@"dark.jpg"]
                 forToolbarPosition:UIToolbarPositionTop
                         barMetrics:UIBarMetricsDefault];
        
        
        //back
        UIImage* inputImage                          = [UIImage imageNamed:@"back.png"];
        CGRect frameInput                            = CGRectMake(0, 0, inputImage.size.width, inputImage.size.height);
        UIButton *inputButton                        = [[UIButton alloc] initWithFrame:frameInput];
        [inputButton setBackgroundImage:inputImage
                               forState:UIControlStateNormal];
        [inputButton addTarget:self
                        action:@selector(dismiss)
              forControlEvents:UIControlEventTouchUpInside];
        UIBarButtonItem *inputButtonItem             = [[UIBarButtonItem alloc] initWithCustomView:inputButton];
        self.navigationItem.leftBarButtonItem=inputButtonItem;
        
        [vc.view addSubview:inputButton];
        
        vc.modalTransitionStyle                      =  UIModalTransitionStyleCoverVertical;
        
        [self presentViewController:vc animated:YES completion:nil];
        
    } else if ([format isEqualToString:@"pdf"])
    {
        ViewReaderController  *viewReaderController =  [[ViewReaderController alloc]initWithNibName:nil bundle:nil];
        viewReaderController.modalTransitionStyle   =  UIModalTransitionStyleCrossDissolve;
        
        UIImage* inputImage                         = [UIImage imageNamed:@"back.png"];
        CGRect frameInput                           = CGRectMake(0, 0, inputImage.size.width, inputImage.size.height);
        UIButton *inputButton                       = [[UIButton alloc] initWithFrame:frameInput];
        [inputButton setBackgroundImage:inputImage
                               forState:UIControlStateNormal];
        [inputButton addTarget:self action:@selector(dismisst)
              forControlEvents:UIControlEventTouchUpInside];
        UIBarButtonItem *inputButtonItem            =  [[UIBarButtonItem alloc] initWithCustomView:inputButton];
        self.navigationItem.leftBarButtonItem       =  inputButtonItem;
        [viewReaderController.view addSubview:inputButton];
        
        [self presentViewController:viewReaderController
                           animated:YES completion:
         ^{
             NSString *newFilePath = [[NSString stringWithFormat:@"%@",filePath]substringFromIndex:16];
             newFilePath = [newFilePath stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
             NSLog(@"OLD FILE PATH: %@", filePath);
             NSLog(@"NEW FILE PATH: %@",newFilePath);
             [viewReaderController initReaderfile:newFilePath];
         }];
        
        
    }
    else if  ([format isEqualToString:@"html"])
    {
        
        Web_ViewController *webViewController       = [[Web_ViewController alloc]init];
        webViewController.view.frame                = [UIScreen mainScreen].bounds;
        
        
        
        UIToolbar *toolbar                         = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, webViewController.view.frame.size.width, 48)];
        [toolbar setBackgroundImage:[UIImage imageNamed:@"dark.jpg"]
                 forToolbarPosition:UIToolbarPositionTop
                         barMetrics:UIBarMetricsDefault];
        
        
        //back
        UIImage* inputImage                        =     [UIImage imageNamed:@"back.png"];
        CGRect frameInput                          =     CGRectMake(0, 0, inputImage.size.width, inputImage.size.height);
        UIButton *inputButton                      =     [[UIButton alloc] initWithFrame:frameInput];
        [inputButton setBackgroundImage:inputImage
                               forState:UIControlStateNormal];
        [inputButton addTarget:self
                        action:@selector(dismiss)
              forControlEvents:UIControlEventTouchUpInside];
        UIBarButtonItem *inputButtonItem           =      [[UIBarButtonItem alloc] initWithCustomView:inputButton];
        self.navigationItem.leftBarButtonItem      =      inputButtonItem;
        [webViewController.view addSubview:inputButton];
        webViewController.modalTransitionStyle     = UIModalTransitionStyleFlipHorizontal;
        [self presentViewController:webViewController
                           animated:YES completion:
         ^{
             NSString *newFilePath = [[[NSString stringWithFormat:@"%@",filePath] substringFromIndex:16]
                                      stringByReplacingOccurrencesOfString:@"%20"
                                      withString:@" "];
             [webViewController initWebview:newFilePath];
         }];
    }
    
}
- (void)dismiss
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (void)dismisst
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
