//
//  ViewReaderController.m
//  iPhoneHTTPServer
//
//  Created by HieuCoder on 8/30/13.
//
//

#import "ViewReaderController.h"
#import "ReaderViewController.h"

@interface ViewReaderController ()

@end

@implementation ViewReaderController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void) initReaderfile:(NSString *)filePath    
{
   ReaderDocument     *document                       = [ReaderDocument withDocumentFilePath:filePath  password:nil];
   if (document != nil)
    {
        ReaderViewController *readerViewController    = [[ReaderViewController alloc] initWithReaderDocument:document];
        readerViewController.delegate                 = self;
        readerViewController.modalTransitionStyle     = UIModalTransitionStyleCrossDissolve;
        readerViewController.modalPresentationStyle   = UIModalPresentationFullScreen;
        [self presentModalViewController:readerViewController animated:YES];
}
}
- (void)dismissReaderViewController:(ReaderViewController *)viewController {
    [self dismissModalViewControllerAnimated:YES];
}

@end
